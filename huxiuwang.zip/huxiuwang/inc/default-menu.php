<ul>
<li>
<a href="<?php echo home_url(); ?>/wp-admin/nav-menus.php">点击设置菜单</a>
</li>
</ul>