<?php get_header(); ?>
<nav class="crumbs container">现在位置： <a title="返回首页" href="<?php bloginfo('url')?>">首页</a> &gt; 
<?php the_terms( $post->ID, 'zts', '', '', '' ); ?> 
 &gt;  正文 </nav>
<section id="main">
<div class="single-con">
<?php if ( have_posts() ) :  while ( have_posts() ) : the_post(); ?>
<div class="container" id="main-con">
<div class="row">
<div class="col-md-9">
<header class="single-header">
<h1><?php the_title(); ?></h1>
<div class="single-meta">
<div class="author">本文作者：<?php the_author_posts_link(); ?></div>
<div class="meta-info">
<span class="time"><i class="fa fa-calendar-check-o"></i><?php echo timeago( get_gmt_from_date(get_the_time('Y-m-d G:i:s')) ) ?></span>
<span class="comment"><i class="fa fa-comments"></i><?php comments_popup_link( '沙发', '评论 1 条', '评论 % 条' ); ?>

</span>
<span class="cate fr"><i class="fa fa-tags"></i><?php the_terms( $post->ID, 'zts', '', '', '' ); ?> </span>
</div>
 </div>
</header>
<div class="single-content">
<?php the_content(); ?>
</div> 

	<div class="post-link-share clearfix">
		<div class="bdsharebuttonbox">
			<span class="share-hmj">分享到：</span>
			<a title="分享到新浪微博" class="bds_tsina fa fa-weibo" href="#" data-cmd="tsina"></a>
			<a title="分享到QQ空间" class="bds_qzone fa fa-star" href="#" data-cmd="qzone"></a>
			<a title="分享到QQ好友" class="qq fa fa-qq" href="#" data-cmd="sqq" ></a>
			<a title="分享到微信" class="bds_weixin fa fa-weixin" href="#" data-cmd="weixin"></a>
			<a class="bds_more fa fa-ellipsis-h" href="#" data-cmd="more"></a>
		</div>
	</div>
 <?php endwhile;endif; ?>
<!-- 广告AD开始 -->
<?php $image = get_field('post-ad','option');if( $image ): ?>
<div class="post-ad ad100">
<?php echo the_field('post-ad','option') ?>
</div>
<?php else : ?>
<?php endif; ?>
<!-- 广告AD结束 -->
<?php comments_template( '', true ); ?>
<section class="related_post">
<h3>相关文章</h3>
<div class="row">
<ul>
    <?php
	$terms = get_the_terms( get_the_ID(), 'zts' ); foreach ( $terms as $term ) {
        $termid = $term->term_taxonomy_id;
    };
   $args = array(
        'post_type' => 'zt', //自定义文章类型名称
        'showposts' => 8, //输出的文章数量，这个可以是缺省值，不用设置
		'post__not_in' => array(get_queried_object_id()) ,
        'tax_query' => array(
            array(
                'taxonomy' => 'zts',//自定义分类法名称
                'terms' =>$termid, //id为64的分类。也可是多个分类array(12,64)
                ),
            )
        );
    $query_posts = new WP_Query($args);
    $query_posts->query($args);
    while ($query_posts->have_posts()) : $query_posts->the_post();
    ?>
   	<li class="col-md-3 col-sm-3 col-xs-6"><a href="<?php the_permalink(); ?>" title="详细阅读 <?php the_title(); ?>">
		 <img class="thumbnail" src="<?php echo get_template_directory_uri(); ?>/timthumb.php?src=<?php echo post_thumbnail_src(); ?>&h=250&w=384&zc=1" alt="<?php the_title(); ?>"/>
		<p><?php echo wp_trim_words( get_the_title(), 60 ); ?></P></a></li>
    <?php endwhile;?>
    <?php wp_reset_query(); ?>
</ul>
</div>
</section>
</div> 
<div class="col-md-3 sidebar hidden-xs hidden-sm">
<?php get_sidebar('single');?>
</div>
</div> 
</div> 
</div>
</section>
<?php get_footer();?>
  
  
  
