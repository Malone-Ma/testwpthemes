<?php if ( is_home() ) { ?><div class="link container"><h3>友情链接</h3><ul><?php wp_list_bookmarks('title_li=&categorize=0'); ?></ul></div><?php } ?>

<section id="footer">
<div class="copyr">
<div class="container">
<p><?php the_field('sm','option')?></p>
<p>©<?php bloginfo('name')?> <?php bloginfo('url')?> <?php echo get_the_date('Y')?> All Rights Reserved | <?php the_field('icp','option')?><?php the_field('tjgj','option')?></p>
</div></div>
</section>
<?php wp_footer(); 
if(strpos(get_home_url(),'localhost')){
  ?>
  <script src="//localhost:35729/livereload.js"></script>
  <?php 
}
?>
<?php if ( is_singular() ){ ?>
<!-- Baidu Button BEGIN -->
<script>
window._bd_share_config = {
    "common": {
        "bdSnsKey": {},
        "bdText": "",
        "bdMini": "2",
        "bdMiniList": false,
        "bdPic": "",
        "bdStyle": "0",
        "bdSize": "16"
    },
    "share": {}
};
with(document) 0[(getElementsByTagName('head')[0] || body).appendChild(createElement('script')).src = 'http://bdimg.share.baidu.com/static/api/js/share.js?v=89860593.js?cdnversion=' + ~ ( - new Date() / 36e5)];
</script>
<!-- Baidu Button END -->
<?php } ?>
<ul id="side-bar" class="side-pannel side-bar hidden-xs">
<a title="回到顶部" href="javascript:;" class="gotop" style="display: block;"><i class="f_top fa fa-chevron-up"></i></a>
</ul>
</body>
</html>
