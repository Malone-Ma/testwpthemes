<?php get_header(); ?>
<section id="main">
<div class="container" id="main-con">
<div class="row">
<div class="col-md-9 content">
<div class="jxdd cats-con">
<h3><em></em><?php single_cat_title(); ?>(<?php  global $wp_query;
$cat_ID = get_query_var('cat');echo get_category($cat_ID)->count;?>篇文章)</h3>
<?php if(category_description()):?>
<p class="cat-des"><?php echo category_description(); ?></p>
<?php else:?> 
<?php endif;?>
</div>
<!-- 文章列表开始 -->
<div class="content-list">
<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
<?php if(!is_sticky()){?>
<?php get_template_part( 'content/content-cat', get_post_format() ); ?>
<?php } endwhile;  endif;?>
<div class="list-nav">
 <span class="nav-next"><?php previous_posts_link('old'); ?></span>
    <span class="nav-previous"><?php next_posts_link('next'); ?></span>
	</div>
	 <?php wp_reset_query(); ?>
</div>
<!-- 文章列表结束 -->
</div>
<div class="col-md-3 sidebar hidden-xs hidden-sm">
<?php get_sidebar('cate');?>
</div>

</div>

</div>
</div>
</section>
<?php get_footer();?>