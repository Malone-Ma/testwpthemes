<?php get_header(); ?>
<section id="main">
<!-- 幻灯片 -->
<div id="slider" class="container">
<div class="big fl">
<?php get_template_part( 'content/big' ); ?>
</div>
<div class="small fl hidden-xs">
<?php get_template_part( 'content/small' ); ?>
</div>
</div>
</div>
<!-- 幻灯片结束 -->
<!-- 广告AD开始 -->
<?php $image = get_field('slider-ad','option');if( $image ): ?>
<div class="container hdp-ad">
<?php echo the_field('slider-ad','option') ?>
</div>
<?php else : ?>
<?php endif; ?>
<!-- 广告AD结束 -->

<!-- 主体内容开始 -->
<div id="main-con" class="container">
<div class="row">
<div class="col-md-9 content">
<!-- 文章列表开始 -->
<div class="content-list" id="content-list">
<?php 
	$result = array_merge($big,$small);
	$paged = get_query_var( 'paged' ) ? get_query_var( 'paged' ) : 1;
	$args = array(	
		'paged' => $paged,
		'ignore_sticky_posts' => 1  ,
		'orderby' => 'date',         // 时间排序
		'order' => 'desc',           // 降序（递减，由大到小）   
		'post__not_in' => $result ,
		
	);
	query_posts( $args );
?>
	<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>

<?php get_template_part( 'content/content', get_post_format() ); ?>
	<?php endwhile;  endif;?>
<?php wp_reset_query(); ?>
<div class="list-nav">
   <?php next_posts_link('next'); ?>
	</div>
</div>
<!-- 文章列表结束 -->
</div>
<div class="col-md-3 sidebar hidden-xs hidden-sm">
<?php get_sidebar();?>
</div>

</div>

</div>
<!-- 主体内容结束 -->
	
</section>

<?php get_footer();?>
  
  
  
