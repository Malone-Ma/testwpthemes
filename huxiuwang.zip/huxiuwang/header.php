<!DOCTYPE html>
<html>
<head>
	<link rel="icon" href="<?php the_field('fav','option')?>" type="image/x-icon" />
	<link rel="shortcut icon" href="<?php the_field('fav','option')?>" type="image/x-icon" />
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="Cache-Control" content="no-transform" /> 
	<meta http-equiv="Cache-Control" content="no-siteapp" />
	<meta name="applicable-device" content="pc,mobile">
		<?php get_template_part( 'content/seo' ); ?>
		<?php wp_head(); ?>
		 <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="http://cdn.bootcss.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="http://cdn.bootcss.com/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<body <?php body_class(); ?>>
<header id="header">
<div class="container">
<div class="header-logo fl">
<?php $logo = get_field('logo','option');
if( !empty($logo) ) {?>
	<a href="<?php bloginfo('url')?>"><img src="<?php echo $logo; ?>" alt="<?php bloginfo('name')?>" /></a>
<?php } else { ?>
<h1><a href="<?php bloginfo('url')?>"><?php bloginfo('name')?></a></h1>
<?php }?>
</div>

<div class="header-menu fl">
 <?php wp_nav_menu( array( 'theme_location' => 'main-nav', 'menu_class' => 'header-menu-con', 'container'=>'','fallback_cb' => 'default_menu') ); ?>
</div>
<div class="header-user fr  hidden-xs">
	 <div class="header-search fl">
		<p><i class="fa fa-search"></i>搜索</p>
		<div class="search-box"><?php get_search_form(); ?></div>
	 </div>
	<div class="user-info fl">
	<?php  if ( is_user_logged_in() ) {
		global $current_user;
	get_currentuserinfo();?>
	<a href="<?php echo get_author_posts_url($current_user->ID); ?>">
	<?php if (function_exists('get_avatar')) { echo get_avatar( $current_user->ID, '30' ); }?></a>
	<?php }else {?>
	<a href="<?php bloginfo('url') ;?>/login">登录</a>
	<a href="<?php bloginfo('url') ;?>/login">注册</a>
	<?php };?>
	</div>
</div>
</div>
</header>
<div class="container-fluid mini"></div>
   