<form method="get" action="<?php bloginfo('url'); ?>" >
	<input type="text" name="s" class="text" autocomplete="off"  placeholder="输入搜索内容">
	<button class="btn-search"> <i class="fa fa-search"></i></button>
</form>