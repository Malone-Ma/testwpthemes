<?php get_header(); ?>
<section id="main">

<div class="container">
<div class="single-con">
<div class="page-center">
<h3>您找的页面不存在</h3>
<ul class="order-menu">
    <li <?php if ( isset($_GET['order']) && ($_GET['order']=='rand') ) echo 'class="current"'; ?> ><a href="<?php the_permalink() ?>/?order=rand" rel="nofollow">随机阅读</a></li>
    <li <?php if ( isset($_GET['order']) && ($_GET['order']=='commented') ) echo 'class="current"'; ?> ><a href="<?php the_permalink() ?>/?order=commented" rel="nofollow">评论最多</a></li>
    <li <?php if ( isset($_GET['order']) && ($_GET['order']=='date') ) echo 'class="current"'; ?> ><a href="<?php the_permalink() ?>/?order=date" rel="nofollow">时间排序</a></li>
</ul>

<ul class="order-list row">

<?php 
		if ( isset($_GET['order']) )
	{
    switch ($_GET['order'])
    {
        case 'rand' : $orderby = 'rand'; break;
        case 'commented' : $orderby = 'comment_count'; break;
        case 'date' : $orderby = 'date'; break;
        default : $orderby = 'date';
    }}else{ $orderby = 'date';}
    $args = array(
    'posts_per_page' => 999999,
    'ignore_sticky_posts' => 1, 
    'orderby' => $orderby,         // 时间排序
    'order' => 'desc',           // 降序（递减，由大到小）     
    );
query_posts( $args );?>
<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
    <li class="col-md-3 col-sm-4 col-xs-6">
    	<figure class="entry-img"> 
	<span class="sort"><?php
$category = get_the_category();
if($category[0]){
echo '<a href="'.get_category_link($category[0]->term_id ).'">'.$category[0]->cat_name.'</a>';
}
?></span>

	
     <a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title(); ?>">
	 	 <img class="thumbnail" src="<?php echo get_template_directory_uri(); ?>/timthumb.php?src=<?php echo post_thumbnail_src(); ?>&h=250&w=384&zc=1" alt="<?php the_title(); ?>" />
			</a>
		</figure>
		<div class="entry-content">
		<h2 class="entry-title"><a href="<?php the_permalink(); ?>" rel="bookmark"><?php the_title(); ?></a></h2>
	
				<div class="entry-meta">
		
		    <div class="time"><span>发布时间：</span><a href="javascript:void(0);"><?php the_time('Y /n/j G:i'); ?></a></div>
			
	
		</div>
		</div>
    </li>
 <?php endwhile;endif; wp_reset_query();?>
 </ul>

</div>

</div>
</div>
</section>
<?php get_footer();?>
  
  
  
