<?php get_header(); ?>
<section id="main">
<div class="container" id="main-con">
<div class="row">
<div class="col-md-9 content">
		<div class="main-author">
<div class="aud-atitle">
				<h3>作者名片</h3>
			</div>
	
				<div class="aud-des-top">
					<div class="left">
						<div class="aud-photo">
						<?php echo get_avatar(get_the_author_meta('ID'),'100'); ?>
						</div>
						<p>
						<?php the_author(); ?><br>
						文章总数:<?php the_author_posts(); ?>
						</p>
					</div>
		
				</div>
				<div class="aud-des-main">
					<p>
					
						<?php the_author_meta('description'); ?>				
					</p>
					<p>微信号：<?php the_author_meta( 'wxh' );?></p>
					<p>邮箱：<?php the_author_meta('email'); ?></p>
					<p>微博：<?php the_author_meta( 'weibo' );?></p>
												
														
						<!-- <p>微信：admin</p> -->
					</div>
			
			</div>
			
<!-- 文章列表开始 -->
<div class="content-list">
<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
<?php if(!is_sticky()){?>
<?php get_template_part( 'content/content', get_post_format() ); ?>
<?php } endwhile;  endif;?>
<div class="list-nav">
 <span class="nav-next"><?php previous_posts_link('old'); ?></span>
    <span class="nav-previous"><?php next_posts_link('next'); ?></span>
	</div>
	 <?php wp_reset_query(); ?>
</div>
<!-- 文章列表结束 -->
</div>
<div class="col-md-3 sidebar hidden-xs hidden-sm">
<?php get_sidebar('cate');?>
</div>

</div>

</div>
</div>
</section>
<?php get_footer();?>
  
  
  

