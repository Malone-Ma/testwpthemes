<?php get_header(); ?>
<?php the_crumbs(); ?>
<section id="main">
<div class="single-con">
<?php if ( have_posts() ) :  while ( have_posts() ) : the_post(); ?>
<div class="container" id="main-con">
<div class="row">
<div class="col-md-9">
<header class="single-header">
<h1><?php the_title(); ?></h1>
<div class="single-meta">
<div class="author">本文作者：<?php the_author_posts_link(); ?></div>
<div class="meta-info">
<span class="time"><i class="fa fa-calendar-check-o"></i><?php echo timeago( get_gmt_from_date(get_the_time('Y-m-d G:i:s')) ) ?></span>
<span class="comment"><i class="fa fa-comments"></i><?php comments_popup_link( '沙发', '评论 1 条', '评论 % 条' ); ?></span>
<span class="cate fr"><i class="fa fa-tags"></i><?php the_category(); ?></span>
</div>
 </div>
</header>
<div class="single-content">
<?php the_content(); ?>
</div> 
 <?php endwhile;endif; ?>
	<div class="post-link-share clearfix">
		<div class="bdsharebuttonbox">
			<span class="share-hmj">分享到：</span>
			<a title="分享到新浪微博" class="bds_tsina fa fa-weibo" href="#" data-cmd="tsina"></a>
			<a title="分享到QQ空间" class="bds_qzone fa fa-star" href="#" data-cmd="qzone"></a>
			<a title="分享到QQ好友" class="qq fa fa-qq" href="#" data-cmd="sqq" ></a>
			<a title="分享到微信" class="bds_weixin fa fa-weixin" href="#" data-cmd="weixin"></a>
			<a class="bds_more fa fa-ellipsis-h" href="#" data-cmd="more"></a>
		</div>
	</div>
<div class="sxp">
<div class="sp"><?php if (get_previous_post()) { previous_post_link('下一篇: %link');} else {echo "没有了，已经是最后文章";} ?></div>
<div class="xp"><?php if (get_next_post()) { next_post_link('上一篇: %link');} else {echo "没有了，已经是最新文章";} ?></div>
</div>

<!-- 广告AD开始 -->
<?php $image = get_field('post-ad','option');if( $image ): ?>
<div class="post-ad ad100">
<?php echo the_field('post-ad','option') ?>
</div>
<?php else : ?>
<?php endif; ?>
<!-- 广告AD结束 -->
<?php comments_template( '', true ); ?>

</div> 
<div class="col-md-3 sidebar hidden-xs hidden-sm">
<?php get_sidebar('single');?>
</div>
</div> 
</div> 
</div>
</section>
<?php get_footer();?>
  
  
  
