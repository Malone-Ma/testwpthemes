
<?php   $m1 = get_field('zhuanlan','options');if( $m1 ):  ?>
<div class="hot-singe widget-container">
<div class="widget-title">
<?php foreach( $m1 as $p ):?>
<h2><?php echo get_the_title( $p->ID ); ?></h2></div>
<div class="sidebar-box"><a href="<?php echo get_permalink( $p->ID ); ?>"><?php echo get_the_post_thumbnail( $p->ID, '', ''); ?></a></div>
<?php endforeach; ?>
</div>
<?php else : ?>
<?php endif; ?>
<?php $terms = get_field('zhuanti','options');if( $terms ): ?>
	<div class="hot-cate widget-container">
	<div class="widget-title">
	<h2><?php $field = get_field_object('zhuanti','option'); echo  $field['label']?></h2></div>
	<div class="sidebar-box">
	<div class="swiper-container">
	<div class="swiper-wrapper">
		<?php foreach( $terms as $term ): ?>

		<div class="swiper-slide">
	<a  href="<?php echo get_term_link( $term ); ?>">
	 <img class=" thumbnail"  src="<?php echo get_template_directory_uri(); ?>/timthumb.php?src=<?php the_field('images',$term)?>&h=250&w=300&zc=1" alt="<?php the_field('text',$term)?>" />
	</a>
	 <div class="shadow"></div>
	<p><a href="<?php echo get_term_link( $term ); ?>"><?php echo $term->name; ?></a></p>
	  
  </div>
	<?php endforeach; ?>
	</div>
	<!-- Add Pagination -->
        <div class="swiper-pagination big-p1"></div>
        <!-- Add Navigation -->
        <div class="icon-arrows-left icon"></div>
        <div class="icon-arrows-right icon"></div>
	</div>
	</div>
	</div>
<?php else : ?>
<?php endif; ?>