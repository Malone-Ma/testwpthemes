<div class="swiper-container">
<div class="swiper-wrapper">
<?php 
	Global $big;
	$big = get_field('big-img', 'option',false, false); 
	$args = array(
	'posts_per_page'	=> 6,
	'post__in'			=> $big,
	'ignore_sticky_posts' => 1,
	'orderby'        	=> 'post__in',
);query_posts($args);?>
 <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
	<div class="swiper-slide">
	 	<span><?php
$category = get_the_category();
if($category[0]){
echo '<a class="lables" href="'.get_category_link($category[0]->term_id ).'">'.$category[0]->cat_name.'</a>';
}
?></span>
	 <a href="<?php the_permalink(); ?>"  title="详细阅读 <?php the_title(); ?>">
	 <img class="thumbnail"  src="<?php echo get_template_directory_uri(); ?>/timthumb.php?src=<?php echo post_thumbnail_src(); ?>&h=570&w=768&zc=1" alt="<?php the_title(); ?>" />
	 </a> 
	 <div class="shadow"></div>
	<p><a class="banner-title" href="<?php the_permalink(); ?>"  title="详细阅读 <?php the_title(); ?>"><?php the_title(); ?></a></p>
	  
  </div>
<?php endwhile; ?>
<?php else : ?>
<?php endif; wp_reset_query(); ?>
</div>
<!-- Add Pagination -->
        <div class="swiper-pagination big-p1"></div>
        <!-- Add Navigation -->
        <div class="icon-arrows-left icon"></div>
        <div class="icon-arrows-right icon"></div>
</div>
  


  
