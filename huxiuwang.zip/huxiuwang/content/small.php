
<?php 
	Global $small;
	$small = get_field('small-img', 'option',false, false); 
	$args = array(
	'posts_per_page'	=> 4,
	'post__in'			=> $small,
	 'ignore_sticky_posts' => 1,
	 'orderby'        	=> 'post__in',
);query_posts($args);?>
 <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
	<div class="item">
	<a href="<?php the_permalink(); ?>" rel="bookmark" title="详细阅读 <?php the_title(); ?>">
	 <img class="thumbnail"  src="<?php echo get_template_directory_uri(); ?>/timthumb.php?src=<?php echo post_thumbnail_src(); ?>&h=214&w=285&zc=1" alt="<?php the_title(); ?>" />
	   <h3>
		   <?php echo wp_trim_words( get_the_title(), 30,'' ); ?>
		  </h3>
		  <div class="shadow"></div>
	 </a> 
	  	
		
	
	  
  </div>
<?php endwhile; ?>
<?php else : ?>
<?php endif; wp_reset_query(); ?>

  
