<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
<div class="row">
	<figure class="entry-img col-md-4 col-sm-4 col-xs-6"> 
<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title(); ?>">
	 <img class="thumbnail" src="<?php echo get_template_directory_uri(); ?>/timthumb.php?src=<?php echo post_thumbnail_src(); ?>&h=250&w=400&zc=1" alt="<?php the_title(); ?>" />
			</a>
		</figure>
		<div class="entry-content col-md-8 col-sm-8 col-xs-6">
		<h2 class="entry-title"><a href="<?php the_permalink(); ?>" rel="bookmark"><?php the_title(); ?></a></h2>
		<div class="entry-meta hidden-xs">
				<div class="author fl">
				<a href="<?php echo get_author_posts_url(get_the_author_meta('ID')); ?>"><?php if (function_exists('get_avatar')) { echo get_avatar( get_the_author_meta('email'), '26' ); }?><span><?php the_author_meta('nickname'); ?></span></a>
				</div>
			<div class="cate fl"><i class="fa fa-tags"></i><?php
$category = get_the_category();
if($category[0]){
echo '<a href="'.get_category_link($category[0]->term_id ).'">'.$category[0]->cat_name.'</a>';
}
?></div>
			<div class="comment fl "><i class="fa fa-comment"></i> <?php comments_number('暂无评论', '1', '%' );?></div>
		    <div class="time fr"><i class="fa fa-calendar-check-o"></i> <a href="javascript:void(0);"><?php echo timeago( get_gmt_from_date(get_the_time('Y-m-d G:i:s')) ) ?></a></div>
			
	
		</div>
		<div class="entry-des hidden-xs">
				<?php the_excerpt(); ?></div>
	
				
		</div>
</div>
</article>


