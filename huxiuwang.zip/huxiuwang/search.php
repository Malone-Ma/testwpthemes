<?php get_header(); ?>
<section id="main">
<div class="container" id="main-con">
<div class="row">
<div class="col-md-9 content">
<div class="jxdd cats-con">
<h3><em></em><?php printf( __( '搜索关键词为: %s', 'xs' ), get_search_query() ); ?> </h3>
<p class="cat-des"><?php global $wp_query; echo $wp_query->found_posts; ?></b>条结果 </p>
</div>
<!-- 文章列表开始 -->
<div class="content-list">
<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
<?php get_template_part( 'content/content', get_post_format() ); ?>
<?php  endwhile;  endif;?>
<div class="list-nav">
 <span class="nav-next"><?php previous_posts_link('old'); ?></span>
    <span class="nav-previous"><?php next_posts_link('next'); ?></span>
	</div>
	 <?php wp_reset_query(); ?>
</div>
<!-- 文章列表结束 -->
</div>
<div class="col-md-3 sidebar">
<?php get_sidebar();?>
</div>

</div>

</div>
</div>
</section>
<?php get_footer();?>
  
  
  
