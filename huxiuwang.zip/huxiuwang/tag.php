<?php get_header(); ?>
<section id="main">
<div class="container tags-con" id="main-con">
<div class="row">
<div class="col-md-10 col-md-offset-1 content">
<div class="tags-con">
<div class="previous-step">
            <a href="/tags">&lt;&nbsp;返回全部标签</a>
        </div>
<h1 class="tag-title"><?php single_cat_title(); ?>(<?php  global $wp_query;
$cat_ID = get_query_var('tag_id');$tag = get_term_by('id', $cat_ID, 'post_tag');echo $tag->count;?>篇文章)</h3>
<p class="cat-des"><?php echo category_description(); ?> </p>
</div>
<!-- 文章列表开始 -->
<div class="content-list">
<div class="title">
<h3>相关文章</h3>
</div>
<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
<?php get_template_part( 'content/content', get_post_format() ); ?>
<?php  endwhile;  endif;?>
<div class="list-nav">
 <span class="nav-next"><?php previous_posts_link('old'); ?></span>
    <span class="nav-previous"><?php next_posts_link('next'); ?></span>
	</div>
	 <?php wp_reset_query(); ?>
</div>
<!-- 文章列表结束 -->
</div>

</div>

</div>
</div>
</section>
<?php get_footer();?>
  
  
  
