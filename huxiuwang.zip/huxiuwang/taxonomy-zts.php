<?php get_header(); ?>
<section id="main">
<div class="container" id="main-con">
<div class="row">
<div class="col-md-9 content">
<div class="jxdd cats-con">
<h3><?php single_cat_title(); ?></h3>
<p class="cat-des"><?php echo term_description(); ?></p>
<div class="term-img">
<img src="<?php $page_id = get_queried_object();  the_field('images',$page_id);?>">
</div>
</div>
<!-- 文章列表开始 -->
<div class="content-list">
<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
<?php if(!is_sticky()){?>
<?php get_template_part( 'content/content-cat', get_post_format() ); ?>
<?php } endwhile;  endif;?>
<div class="list-nav">
 <span class="nav-next"><?php previous_posts_link('old'); ?></span>
    <span class="nav-previous"><?php next_posts_link('next'); ?></span>
	</div>
	 <?php wp_reset_query(); ?>
</div>
<!-- 文章列表结束 -->
</div>
<div class="col-md-3 sidebar hidden-xs hidden-sm">
<?php get_sidebar('cate');?>
</div>

</div>

</div>
</div>
</section>
<?php get_footer();?>
  
  
  
