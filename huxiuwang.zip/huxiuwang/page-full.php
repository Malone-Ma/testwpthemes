<?php 
/*
Template Name:通栏页面
*/
get_header(); ?>
<section id="main">
<div class="container">
<div class="row">
<div class="single-con">
<div class="col-md-10 col-md-offset-1 page-bg">
<?php if ( have_posts() ) :  while ( have_posts() ) : the_post(); ?>
<div class="single-content">
<h1 class="page-title"><?php the_title(); ?></h1>
<?php the_content(); ?>
</div> 
 <?php endwhile;endif; ?>
 <?php comments_template( '', true ); ?>
</div>


</div>
</div>
</div>
</section>
<?php get_footer();?>
  
  
  
