<?php 
/*
Template Name:专题页面
*/
get_header(); ?>
<section id="main">

<div class="container">
<div class="single-con">
<div class="page-zt">
<h3><?php the_title();?></h3>

<div class="row">
<?php $terms = get_terms('zts', array(
    'orderby'    => 'id',
  'hierarchical' => 0,
  'hide_empty' => 1,
  'pad_counts'   => 1,     // 1 for yes, 0 for no
  'parent'=>0,
  'hide_empty'=>0,
) );foreach ( $terms as $term ) : setup_postdata( $term );?>

<div class="col-md-6 term-list">
<a href="<?php echo get_term_link($term->term_id); ?>"><img class="thumbnail" src="<?php echo get_template_directory_uri(); ?>/timthumb.php?src=<?php the_field('images',$term)?>&h=350&w=570&zc=1" alt="<?php the_title(); ?>" /></a>
<h4><a href="<?php echo get_term_link($term->term_id); ?>"><?php echo $term->name; ?></a></h4>
<p class="des"><?php  echo $term->description;?></p>

</div>
<?php endforeach; ?> 
</div>
</div>

</div>
</div>
</section>
<?php get_footer();?>
  
  
  
