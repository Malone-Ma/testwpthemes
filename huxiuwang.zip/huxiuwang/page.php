<?php 

get_header(); ?>
<section id="main">

<div class="container">
<div class="row">
<div class="single-con">
<div class="col-md-3 col-sm-3 col-xs-3">
<?php wp_nav_menu( array( 'theme_location' => 'page-nav', 'menu_class' => 'page-menu', 'container'=>'') ); ?>
</div>

<div class="col-md-9 col-sm-9 col-xs-9 page-bg">
<?php if ( have_posts() ) :  while ( have_posts() ) : the_post(); ?>
<div class="single-content">
<h1 class="page-title"><?php the_title(); ?></h1>
<?php the_content(); ?>
</div> 
 <?php endwhile;endif; ?>
</div>


</div>
</div>
</div>
</section>
<?php get_footer();?>
  
  
  
